#include <fcntl.h>
#include <internal/syscall.h>
#include <internal/io.h>
#include <stdio.h>
#include <errno.h>

int puts(const char * str)
{
    int len = 0;
    while (*str != '\0') {
        if (write(1, str, 1) == -1) {
            return EOF;
        }
        str++;
        len++;
    }

    if (write(1, "\n", 1) == -1) {
        return EOF;
    }
    len++;
    return len;
}