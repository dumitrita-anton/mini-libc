// SPDX-License-Identifier: BSD-3-Clause

#include <internal/mm/mem_list.h>
#include <internal/types.h>
#include <internal/essentials.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <string.h>
#include <stdlib.h>

void *malloc(size_t size)
{
	return (void *)mmap(NULL, size, PROT_READ | PROT_WRITE, 
						MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
}

void *calloc(size_t nmemb, size_t size)
{

    void *res = (void *)mmap(NULL, nmemb * size , PROT_READ | PROT_WRITE,
                     MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    
	if (res == MAP_FAILED) {
        return NULL;
    }

    memset(res, 0, nmemb * size);
    
	return res;
   
}

void free(void *ptr)
{
	if (ptr == NULL) {
        return;
    }

	char *aux = (char *)ptr;
		aux--;	
	munmap(ptr, *aux);
	

}


void *realloc(void *ptr, size_t size)
{
	void *new_ptr = malloc(size);
	char *p1 = ptr;
	char *p2 = new_ptr;

	for (size_t i = 0; i < size; i++) {
		if (i < (size_t)((char *)ptr + size - (char *)new_ptr)) {
			p2[i] = p1[i];
		}
		else {
			break;
		}
	}
	free(ptr);
	return new_ptr;
}

void *reallocarray(void *ptr, size_t nmemb, size_t size)
{
	void *new_ptr = realloc(ptr, size * nmemb);
	return new_ptr;
}
