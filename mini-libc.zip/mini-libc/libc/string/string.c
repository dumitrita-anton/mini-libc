/* SPDX-License-Identifier: BSD-3-Clause */

#include <string.h>

char *strcpy(char *destination, const char *source)
{
	char *d;

	for(d = destination; *source != '\0'; source++, d++) {
		*d = *source;
	}

	*d = *source;
	return destination;
}

char *strncpy(char *destination, const char *source, size_t len)
{

	char *d;

	for(d = destination; *source != '\0' && len > 0; source++, d++, len--) {
		*d = *source;
	}

	*d = *source;
	return destination;
}

char *strcat(char *destination, const char *source)
{

	char *d = destination + strlen(destination);

	while (*source != '\0') {
		*d++ = *source++;
	}

	*d = '\0';

	return destination;
}

char *strncat(char *destination, const char *source, size_t len)
{

	char *d = destination + strlen(destination);

	while (*source != '\0' && len > 0) {
		*d++ = *source++;
		len--;
	}

	*d = '\0';

	return destination;
}

int strcmp(const char *str1, const char *str2)
{
	
	while (*str1 != '\0' && *str1 == *str2) {
        str1++;
        str2++;
    }

    return *str1 - *str2;

}

int strncmp(const char *str1, const char *str2, size_t len)
{

	char c1, c2;

	while (len-- > 0) {
		c1 = *str1++;
		c2 = *str2++;
		if (c1 != c2)
			return c1 - c2;
		if (c1 == '\0')
			return 0;
	}
	return 0;
}

size_t strlen(const char *str)
{
	size_t i = 0;

	for (; *str != '\0'; str++, i++)
		;

	return i;
}

char *strchr(const char *str, int c)
{
	
	while (*str != '\0') {
        if (*str == c)
            return (char *) str;

        str++;
    }

	return NULL;
}

char *strrchr(const char *str, int c)
{
	char *found = 0;
	while (*str != '\0') {
        if (*str == c)
            found = (char *) str;

        str++;
    }

	return found;		
}

char *strstr(const char *str1, const char *str2)
{
	const char *h, *n;

    if (*str2 == '\0')
        return (char *) str1;

    while (*str1 != '\0')
    {
        h = str1;
        n = str2;

        while (*n != '\0' && *h == *n) {
            h++;
            n++;
        }

        if (*n == '\0')
            return (char *) str1;

        str1++;
    }
	return NULL;
}

char *strrstr(const char *str1, const char *str2)
{
	int len_h = strlen(str1);
    int len_n = strlen(str2);

    if (len_n > len_h)
        return NULL;

    char *ptr = NULL;
    char *found = NULL;

    while ((ptr = strstr(str1, str2)) != NULL) {
        found = ptr;
        str1 = ptr + 1;
    }

	return found;
}

void *memcpy(void *destination, const void *source, size_t num)
{
	
	char *d = (char *) destination;
    const char *s = (const char *) source;

    while (num--) {
        *d++ = *s++;
	}

	return destination;
}

void *memmove(void *destination, const void *source, size_t num)
{
	char *d = (char *) destination;
    const char *s = (const char *) source;

    if (s < d) {
        s += num;
        d += num;

        while (num--)
            *--d = *--s;
    }
    else {
        while (num--)
            *d++ = *s++;
	}

	return destination;
}

int memcmp(const void *ptr1, const void *ptr2, size_t num)
{
	char *s1 = (char *)ptr1;
	char *s2 = (char *)ptr2;

	while (num-- > 0) {
		if (*s1++ != *s2++)
			return s1[-1] < s2[-1] ? -1 : 1;
	}
	return 0;
}

void *memset(void *source, int value, size_t num)
{
	char *ptr = (char *)source;
	while (num-- > 0)
		*ptr++ = value;

	return source;
}
